// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

/**
 * @title TartMockFeeConverterRouter
 * @notice Test-only router for TartFeeConverter safety coverage.
 */
contract TartMockFeeConverterRouter {
    using SafeERC20 for IERC20;

    uint256 public outputBps = 10_000;

    function setOutputBps(uint256 outputBps_) external {
        outputBps = outputBps_;
    }

    function getAmountsOut(uint256 amountIn, address[] calldata path) external view returns (uint256[] memory amounts) {
        require(path.length >= 2, "Bad path");
        amounts = new uint256[](path.length);
        amounts[0] = amountIn;
        amounts[path.length - 1] = amountIn * outputBps / 10_000;
    }

    function swapExactTokensForTokensSupportingFeeOnTransferTokens(
        uint256 amountIn,
        uint256 amountOutMin,
        address[] calldata path,
        address to,
        uint256
    ) external {
        require(path.length >= 2, "Bad path");
        uint256 amountOut = amountIn * outputBps / 10_000;
        require(amountOut >= amountOutMin, "Insufficient output");
        IERC20(path[0]).safeTransferFrom(msg.sender, address(this), amountIn);
        IERC20(path[path.length - 1]).safeTransfer(to, amountOut);
    }
}
