// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

/**
 * @title TartMockPancakeRouterV2
 * @notice Test-only PancakeRouter-like contract. It is intentionally simple and should never be used in production.
 */
contract TartMockPancakeRouterV2 {
    using SafeERC20 for IERC20;

    address private immutable _weth;

    constructor(address weth_) {
        _weth = weth_;
    }

    receive() external payable {}

    function WETH() external view returns (address) {
        return _weth;
    }

    function swapExactTokensForTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint
    ) external returns (uint[] memory amounts) {
        require(path.length >= 2, "Bad path");
        uint256 received = _pull(path[0], msg.sender, amountIn);
        require(received >= amountOutMin, "Insufficient output");
        IERC20(path[path.length - 1]).safeTransfer(to, received);
        amounts = new uint[](path.length);
        amounts[0] = amountIn;
        amounts[path.length - 1] = received;
    }

    function swapExactETHForTokens(
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint
    ) external payable returns (uint[] memory amounts) {
        require(path.length >= 2 && path[0] == _weth, "Bad path");
        require(msg.value >= amountOutMin, "Insufficient output");
        IERC20(path[path.length - 1]).safeTransfer(to, msg.value);
        amounts = new uint[](path.length);
        amounts[0] = msg.value;
        amounts[path.length - 1] = msg.value;
    }

    function swapExactTokensForETH(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint
    ) external returns (uint[] memory amounts) {
        require(path.length >= 2 && path[path.length - 1] == _weth, "Bad path");
        uint256 received = _pull(path[0], msg.sender, amountIn);
        require(received >= amountOutMin, "Insufficient output");
        (bool ok, ) = payable(to).call{value: received}("");
        require(ok, "Native transfer failed");
        amounts = new uint[](path.length);
        amounts[0] = amountIn;
        amounts[path.length - 1] = received;
    }

    function swapExactTokensForTokensSupportingFeeOnTransferTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint
    ) external {
        require(path.length >= 2, "Bad path");
        uint256 received = _pull(path[0], msg.sender, amountIn);
        require(received >= amountOutMin, "Insufficient output");
        IERC20(path[path.length - 1]).safeTransfer(to, received);
    }

    function swapExactETHForTokensSupportingFeeOnTransferTokens(
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint
    ) external payable {
        require(path.length >= 2 && path[0] == _weth, "Bad path");
        require(msg.value >= amountOutMin, "Insufficient output");
        IERC20(path[path.length - 1]).safeTransfer(to, msg.value);
    }

    function swapExactTokensForETHSupportingFeeOnTransferTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint
    ) external {
        require(path.length >= 2 && path[path.length - 1] == _weth, "Bad path");
        uint256 received = _pull(path[0], msg.sender, amountIn);
        require(received >= amountOutMin, "Insufficient output");
        (bool ok, ) = payable(to).call{value: received}("");
        require(ok, "Native transfer failed");
    }

    function addLiquidity(
        address tokenA,
        address tokenB,
        uint amountADesired,
        uint amountBDesired,
        uint,
        uint,
        address,
        uint
    ) external returns (uint amountA, uint amountB, uint liquidity) {
        amountA = _pull(tokenA, msg.sender, amountADesired);
        amountB = _pull(tokenB, msg.sender, amountBDesired);
        liquidity = amountA < amountB ? amountA : amountB;
    }

    function addLiquidityETH(
        address token,
        uint amountTokenDesired,
        uint,
        uint,
        address,
        uint
    ) external payable returns (uint amountToken, uint amountETH, uint liquidity) {
        amountToken = _pull(token, msg.sender, amountTokenDesired);
        amountETH = msg.value;
        liquidity = amountToken < amountETH ? amountToken : amountETH;
    }

    function removeLiquidity(
        address tokenA,
        address tokenB,
        uint liquidity,
        uint,
        uint,
        address to,
        uint
    ) external returns (uint amountA, uint amountB) {
        liquidity;
        amountA = IERC20(tokenA).balanceOf(address(this)) / 10;
        amountB = IERC20(tokenB).balanceOf(address(this)) / 10;
        if (amountA > 0) IERC20(tokenA).safeTransfer(to, amountA);
        if (amountB > 0) IERC20(tokenB).safeTransfer(to, amountB);
    }

    function removeLiquidityETH(
        address token,
        uint liquidity,
        uint,
        uint,
        address to,
        uint
    ) external returns (uint amountToken, uint amountETH) {
        liquidity;
        amountToken = IERC20(token).balanceOf(address(this)) / 10;
        amountETH = address(this).balance / 10;
        if (amountToken > 0) IERC20(token).safeTransfer(to, amountToken);
        if (amountETH > 0) {
            (bool ok, ) = payable(to).call{value: amountETH}("");
            require(ok, "Native transfer failed");
        }
    }

    function _pull(address token, address from, uint256 amount) internal returns (uint256 received) {
        uint256 beforeBalance = IERC20(token).balanceOf(address(this));
        IERC20(token).safeTransferFrom(from, address(this), amount);
        uint256 afterBalance = IERC20(token).balanceOf(address(this));
        require(afterBalance >= beforeBalance, "Bad token balance");
        received = afterBalance - beforeBalance;
    }
}
