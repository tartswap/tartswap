// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title TartMockRevertingNativeReceiver
 * @notice Test-only receiver that rejects native transfers.
 */
contract TartMockRevertingNativeReceiver {
    receive() external payable {
        revert("Reject native");
    }
}
