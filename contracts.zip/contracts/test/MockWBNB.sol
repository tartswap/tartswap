// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";

contract TartMockWBNB is ERC20 {
    constructor() ERC20("Wrapped BNB", "WBNB") {}

    receive() external payable {
        deposit();
    }

    function deposit() public payable {
        require(msg.value > 0, "Zero native");
        _mint(msg.sender, msg.value);
    }
}
