// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";

/**
 * @title TartMockFeeOnTransferERC20
 * @notice Test-only taxed token used to verify router, farm and staking accounting.
 */
contract TartMockFeeOnTransferERC20 is ERC20, Ownable {
    uint16 public taxBps;
    address public taxRecipient;
    mapping(address => bool) public isTaxExempt;

    constructor(string memory name_, string memory symbol_, uint16 taxBps_, address taxRecipient_) ERC20(name_, symbol_) Ownable(msg.sender) {
        require(taxBps_ <= 2_000, "Tax too high");
        require(taxRecipient_ != address(0), "Zero tax recipient");
        taxBps = taxBps_;
        taxRecipient = taxRecipient_;
        isTaxExempt[msg.sender] = true;
    }

    function mint(address to, uint256 amount) external onlyOwner {
        _mint(to, amount);
    }

    function setTax(uint16 taxBps_, address taxRecipient_) external onlyOwner {
        require(taxBps_ <= 2_000, "Tax too high");
        require(taxRecipient_ != address(0), "Zero tax recipient");
        taxBps = taxBps_;
        taxRecipient = taxRecipient_;
    }

    function setTaxExempt(address account, bool exempt) external onlyOwner {
        isTaxExempt[account] = exempt;
    }

    function _update(address from, address to, uint256 value) internal override {
        if (from != address(0) && to != address(0) && taxBps > 0 && !isTaxExempt[from] && !isTaxExempt[to]) {
            uint256 fee = (value * taxBps) / 10_000;
            uint256 net = value - fee;
            super._update(from, taxRecipient, fee);
            super._update(from, to, net);
        } else {
            super._update(from, to, value);
        }
    }
}
